<!DOCTYPE html>
<html>
<head>
	<title>Well Come</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/newcss.css">
	
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
		<nav class="navbar bg-white navbar-dark fixed-top">
  <li class="navbar-brand ">
  	<a class="navbar-brand" style="color: black;font-size: 15px;" href="#">Wellcome taj's Catering</a>
  </li>
  <div class="topnav-right color">
    
    	<li class="navbar-brand "><a style="color: black;text-decoration: none" href="#about">About</a></li>
    	<li class="navbar-brand"><a style="color: black;text-decoration: none" href="#menu">Menu</a></li>
    	<li class="navbar-brand"><a style="color: black;text-decoration: none" href="#contact">Contact</a></li>
   
    
  </div>
 
</nav> <!--end of nav-->
 <img style="height: 700px;width: 100%" src="img/hamburger.jpg">
	<div class="container">
		<div class="row" style="margin-bottom: 100px;">
		<div class="col-md-6" style="margin-top: 80px;">
			<img style="height: 550px;width: 450px;margin-left: auto;" src="img/tablesetting2.jpg">
		</div>

		<div id="about" class="col-md-6" style="margin-top: 80px;">
			 <h1 style="text-align: center">About Catering</h1>
			 <h5 style="text-align: center;margin-top: 50px;margin-bottom: 30px;">Tradition since 2020</h5>
			 <p style="font-size: 18px!important;">The Catering was founded in blabla by Md. Taj in lorem ipsum dolor sit amet, consectetur adipiscing elit consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute iruredolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.We only use seasonal ingredients.<br><br></p>
			 <p style="color: #757575!important;font-size: 18px!important;">Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod temporincididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
		</div>
		</div><!--end of first row-->
		<hr>
		<div class="row"style="margin-bottom: 100px;">
			
		<div id="menu" class="col-md-6" style="margin-top: 80px;">
			 <h1 style="text-align: center;margin-bottom: 40px;">Our Menu</h1>
			 <h5>Bread Basket</h5>
			 <p>Assortment of fresh baked fruit breads and muffins 5.50</p>
			 <h5 style="margin-top: 45px;">Honey Almond Granola with Fruits</h5>
			 <p>Natural cereal of honey toasted oats, raisins, almonds and dates 7.00</p>
			 <h5 style="margin-top: 45px;">Belgian Waffle</h5>
			 <p>Vanilla flavored batter with malted flour 7.50</p>
			 <h5 style="margin-top: 45px;">Scrambled eggs</h5>
			 <p>Scrambled eggs, roasted red pepper and garlic, with green onions 7.50</p>
			 <h5 style="margin-top: 45px;">Blueberry Pancakes</h5>
			 <p>With syrup, butter and lots of berries 8.50</p>
		</div>
		<div class="col-md-6" style="margin-top: 80px;">
			<img style="height: 600px;width: 450px;margin-left: auto;" src="img/tablesetting.jpg">
		</div>
		</div><!--end of second row-->
		<hr>
		<h2 id="contact" style="margin-top: 100px;margin-bottom: 50px;">Contact</h2>
		<p>We offer full-service catering for any event, large or small. We understand your needs and we will cater the food to satisfy the biggerst criteria of them all, both look and taste. Do not hesitate to contact us.</p>
		<h6 style="margin-top: 25px;margin-bottom: 25px;">Catering Service, Grameen abashik,Khulna, BD</h6>
		<p style="margin-bottom: 20px;">You can also contact us by phone 01992049706 or email tajuddinjoy849@gmail.com, or you can send us a message here:</p>
		<input style="width: 100%;margin-bottom: 20px;height: 50px;border: none;border-bottom: 1px solid #ccc;padding-left: 5px;" type="text" name="" placeholder="name">
		<input style="width: 100%;margin-bottom: 20px;height: 50px;border: none;border-bottom: 1px solid #ccc;padding-left: 5px;" type="number" name="" placeholder="How many people">
		<input style="width: 100%;margin-bottom: 20px;height: 50px;border: none;border-bottom: 1px solid #ccc;padding-left: 5px;" type="datetime-local" name="" placeholder="Date and Time">
		<input style="width: 100%;margin-bottom: 20px;height: 50px;border: none;border-bottom: 1px solid #ccc;padding-left: 5px;" type="text" name="" placeholder="Message">
		<button type="button" class="btn btn-light" style="margin-bottom: 100px;">
			<a style="letter-spacing: 0px;text-decoration: none;color: black" href="" style="color:black;text-decoration: none ">SEND MESSAGE</a>
		</button>
		
	</div><!--end of container div-->
	<footer style="background-color: #ccc;height:120px;text-align: center;line-height: 120px">
		<p>Powered by Joy</p>
	</footer>

</body>
</html>